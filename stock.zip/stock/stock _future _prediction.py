#!/usr/bin/env python
# coding: utf-8

# In[55]:


import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import TimeSeriesSplit
from tensorflow import keras
from tensorflow.keras import layers
from tensorflow.keras.callbacks import EarlyStopping, ReduceLROnPlateau
from tensorflow.keras.models import load_model
import yfinance as yf
from datetime import datetime
import glob
import tensorflow as tf
import warnings
import os

try:
    import ipywidgets as widgets
    from IPython.display import display
    JUPYTER_AVAILABLE = True
except ImportError:
    JUPYTER_AVAILABLE = False
    print("⚠️ ipywidgets not available. UI will not be displayed.")

warnings.filterwarnings('ignore')

# --- Configuration ---
N_STEPS = 10
LOOKUP_STEP = 1
TEST_SIZE = 0.1
BATCH_SIZE = 32
EPOCHS = 30
PATIENCE = 5
LEARNING_RATE = 0.0001
N_FOLDS = 3

# === Technical indicators and helper functions ===

def compute_rsi(series, period=14):
    delta = series.diff()
    gain = delta.where(delta > 0, 0).rolling(window=period).mean()
    loss = (-delta.where(delta < 0, 0)).rolling(window=period).mean()
    rs = gain / loss
    rs[rs.isna()] = 0
    return 100 - (100 / (1 + rs))

def compute_macd(series, fast=12, slow=26, signal=9):
    exp1 = series.ewm(span=fast, adjust=False).mean()
    exp2 = series.ewm(span=slow, adjust=False).mean()
    macd = exp1 - exp2
    signal_line = macd.ewm(span=signal, adjust=False).mean()
    return macd, signal_line

def compute_atr(high, low, close, period=14):
    tr = pd.DataFrame(index=high.index)
    tr['HL'] = high - low
    tr['HC'] = (high - close.shift()).abs()
    tr['LC'] = (low - close.shift()).abs()
    tr['TR'] = tr[['HL', 'HC', 'LC']].max(axis=1)
    return tr['TR'].rolling(window=period).mean()

def compute_adx(high, low, close, period=14):
    tr = compute_atr(high, low, close, period)
    dm_plus = (high - high.shift()).where(high > high.shift(), 0)
    dm_minus = (low.shift() - low).where(low < low.shift(), 0)
    dm_plus = dm_plus.rolling(window=period).mean()
    dm_minus = dm_minus.rolling(window=period).mean()
    di_plus = (dm_plus / tr) * 100
    di_minus = (dm_minus / tr) * 100
    dx = ((di_plus - di_minus).abs() / (di_plus + di_minus)) * 100
    return dx.rolling(window=period).mean()

def compute_stochastic_oscillator(high, low, close, period=14):
    lowest_low = low.rolling(window=period).min()
    highest_high = high.rolling(window=period).max()
    stochastic = 100 * (close - lowest_low) / (highest_high - lowest_low)
    return stochastic

def compute_rvi(close, open_, high, low, period=14):
    num = (close - open_).rolling(window=period).mean()
    denom = (high - low).rolling(window=period).mean()
    rvi = num / denom
    rvi_signal = rvi.rolling(window=4).mean()
    return rvi_signal

def compute_williams_r(high, low, close, period=14):
    highest_high = high.rolling(window=period).max()
    lowest_low = low.rolling(window=period).min()
    return -100 * (highest_high - close) / (highest_high - lowest_low)

def add_indicators(df):
    required = {'Close', 'High', 'Low', 'Volume', 'Open'}
    if not required.issubset(df.columns):
        raise ValueError(f"DataFrame missing required columns: {required - set(df.columns)}")

    df = df.copy()
    df['RSI'] = compute_rsi(df['Close'])
    df['MACD'], df['MACD_signal'] = compute_macd(df['Close'])
    df['MACD_Hist'] = df['MACD'] - df['MACD_signal']
    df['EMA_10'] = df['Close'].ewm(span=10, adjust=False).mean()
    df['ATR'] = compute_atr(df['High'], df['Low'], df['Close'])
    df['ATR_Norm'] = df['ATR'] / df['Close']
    df['ADX'] = compute_adx(df['High'], df['Low'], df['Close'])
    df['Momentum'] = df['Close'].pct_change(3)
    df['VWAP'] = (df['Close'] * df['Volume']).cumsum() / df['Volume'].cumsum()
    df['Stochastic'] = compute_stochastic_oscillator(df['High'], df['Low'], df['Close'])
    df['RVI'] = compute_rvi(df['Close'], df['Open'], df['High'], df['Low'])
    df['ROC'] = df['Close'].pct_change(5) * 100
    df['Williams_R'] = compute_williams_r(df['High'], df['Low'], df['Close'])
    df['OBV'] = (np.sign(df['Close'].diff()) * df['Volume']).cumsum()
    df['Volatility_10'] = df['Close'].rolling(window=10).std()
    from ta.volume import ChaikinMoneyFlowIndicator
    from ta.volatility import BollingerBands

# Bollinger Band Width
    bb = BollingerBands(close=df['Close'], window=20, window_dev=2)
    df['BB_Width'] = bb.bollinger_hband() - bb.bollinger_lband()
    # --- Lag Features ---
    for lag in range(1, 6):
        df[f'Lag_Close_{lag}'] = df['Close'].shift(lag)
        df[f'Lag_Volume_{lag}'] = df['Volume'].shift(lag)

    # --- Calendar Features ---
    df['DayOfWeek'] = df.index.dayofweek
    df['Month'] = df.index.month
    df['IsMonthEnd'] = df.index.is_month_end.astype(int)
    df['IsMonthStart'] = df.index.is_month_start.astype(int)

    # Final cleanup
    df = df.fillna(method='ffill').fillna(0)
    df.dropna(inplace=True)
    return df


def feature_selection(df):
    corr = df.corr()['Close'].abs()
    print(f"Correlation with Close:\n{corr}")

    selected = corr[corr > 0.1].index.tolist()

    # Force-include these even if correlation is low
    must_have = [
        'Close',
        'MACD', 'MACD_signal',
        'EMA_10',
        'ATR',
        'VWAP',
        'ROC',
        'Volatility_10',
        'OBV',
        'Lag_Close_2'
    ]



    selected = list(set(selected + must_have))
    print(f"Selected features: {selected}")
    return selected

def inverse_transform_single_column(predictions, column_index, scaler):
    mean_ = scaler.mean_[column_index]
    scale_ = scaler.scale_[column_index]
    preds = predictions.flatten()
    return preds * scale_ + mean_

def load_data(ticker, n_steps=N_STEPS, lookup_step=LOOKUP_STEP, test_size=TEST_SIZE):
    print(f"Attempting to download data for {ticker}...")
    try:
        df = yf.download(ticker, period="5y", interval="1d", auto_adjust=True)
        print(f"Downloaded data shape: {df.shape}")
        print(f"Columns: {list(df.columns)}")
    except Exception as e:
        raise ValueError(f"Failed to download data for {ticker}: {e}")

    if df.empty:
        raise ValueError(f"DataFrame for {ticker} is empty")

    if isinstance(df.columns, pd.MultiIndex):
        df.columns = [col[0] for col in df.columns]
        print(f"Flattened columns: {list(df.columns)}")

    if not {'Open', 'High', 'Low', 'Close', 'Volume'}.issubset(df.columns):
        raise ValueError(f"DataFrame missing required columns: {list(df.columns)}")

    # Outlier filtering
    df = df[df['Close'].between(df['Close'].quantile(0.005), df['Close'].quantile(0.995))]

    # Keep only OHLCV
    df = df[['Open', 'High', 'Low', 'Close', 'Volume']]

    # Add indicators
    df = add_indicators(df)

    # 👉 INSERTED BLOCK: Compute classification label with threshold
    THRESHOLD = 0.005  # 0.5%
    future_price = df['Close'].shift(-lookup_step)
    percent_change = (future_price - df['Close']) / df['Close']
    df['Price_Direction'] = (percent_change > THRESHOLD).astype(int)

    # Feature selection and cleaning
    feature_columns = feature_selection(df)
    df = df[feature_columns].dropna()
    print(f"DataFrame shape after preprocessing: {df.shape}")

    if df.empty:
        raise ValueError("DataFrame is empty after preprocessing. Check feature selection or data quality.")

    # Scale features
    data = df.values
    scaler = StandardScaler()
    scaled = scaler.fit_transform(data)

    # Indexes
    close_idx = feature_columns.index("Close")
    direction_idx = feature_columns.index("Price_Direction") if "Price_Direction" in feature_columns else None

    # Prepare sequences
    X, y_reg, y_clf = [], [], []
    for i in range(n_steps, len(scaled) - lookup_step + 1):
        X.append(scaled[i - n_steps:i])
        y_reg.append(scaled[i + lookup_step - 1][close_idx])
        if direction_idx is not None:
            y_clf.append(scaled[i + lookup_step - 1][direction_idx])

    X, y_reg, y_clf = np.array(X), np.array(y_reg), np.array(y_clf)
    print(f"X shape: {X.shape}, y_reg shape: {y_reg.shape}, y_clf shape: {y_clf.shape}")

    # Train/test split
    test_size_int = int(test_size * len(X))
    if test_size_int == 0:
        raise ValueError("Test set is empty. Reduce n_steps or increase data size.")

    return (
        X[:-test_size_int], X[-test_size_int:], 
        y_reg[:-test_size_int], y_reg[-test_size_int:], 
        y_clf[:-test_size_int], y_clf[-test_size_int:], 
        scaler, df.index[-len(y_reg):], df, close_idx, direction_idx
    )


def custom_loss(y_true, y_pred):
    mse = tf.reduce_mean(tf.square(y_true - y_pred))
    direction_true = tf.sign(y_true[1:] - y_true[:-1])
    direction_pred = tf.sign(y_pred[1:] - y_pred[:-1])
    direction_loss = tf.reduce_mean(tf.cast(tf.not_equal(direction_true, direction_pred), tf.float32))
    return mse + 1.5 * direction_loss

def calculate_metrics(y_true, y_pred):
    y_true, y_pred = np.array(y_true), np.array(y_pred)
    nonzero_idx = y_true != 0
    mape = np.mean(np.abs((y_true[nonzero_idx] - y_pred[nonzero_idx]) / y_true[nonzero_idx])) * 100 if np.any(nonzero_idx) else np.nan
    rmse = np.sqrt(np.mean((y_true - y_pred) ** 2))
    direction_true = np.sign(y_true[1:] - y_true[:-1])
    direction_pred = np.sign(y_pred[1:] - y_pred[:-1])
    directional_acc = np.mean(direction_true == direction_pred) * 100
    return mape, rmse, directional_acc

def calculate_directional_accuracy(y_true, y_pred):
    y_true, y_pred = np.array(y_true), np.array(y_pred)
    direction_true = np.sign(y_true[1:] - y_true[:-1])
    direction_pred = np.sign(y_pred[1:] - y_pred[:-1])
    return np.mean(direction_true == direction_pred) * 100

def find_latest_model_date(ticker, model_type):
    model_dir = f"models/{ticker}"
    pattern = os.path.join(model_dir, f"reg_model_{model_type}_fold0_*.keras")
    files = glob.glob(pattern)
    dates = []
    for f in files:
        basename = os.path.basename(f)
        date_str = basename.split("_")[-1].replace(".keras", "")
        try:
            dates.append(datetime.strptime(date_str, "%Y-%m-%d"))
        except:
            continue
    return max(dates) if dates else None

from tensorflow.keras.layers import Bidirectional
def build_model(model_type, input_shape, bidirectional=False, for_classification=False):
    inputs = keras.Input(shape=input_shape)

    if model_type == "GRU":
        base_layer = layers.GRU(64, return_sequences=True)
    elif model_type == "LSTM":
        base_layer = layers.LSTM(64, return_sequences=True)
    elif model_type == "Conv1D":
        base_layer = layers.Conv1D(64, kernel_size=3, activation='relu', padding='same')
    elif model_type == "Dense":
        base_layer = layers.TimeDistributed(layers.Dense(64, activation='relu'))
    else:
        raise ValueError(f"Unknown model_type: {model_type}")

    if bidirectional and model_type in ['GRU', 'LSTM']:
        x = Bidirectional(base_layer)(inputs)
    else:
        x = base_layer(inputs)

    if model_type != "Conv1D":
        x = layers.Conv1D(32, kernel_size=3, activation='relu', padding='same')(x)

    x = layers.BatchNormalization()(x)
    x = layers.MultiHeadAttention(num_heads=4, key_dim=64//8)(x, x)
    x = layers.GlobalAveragePooling1D()(x)
    x = layers.Dropout(0.3)(x)
    x = layers.Dense(32, activation='relu', kernel_regularizer=keras.regularizers.l2(0.01))(x)

    outputs = layers.Dense(1, activation='sigmoid' if for_classification else None)(x)

    model = keras.Model(inputs=inputs, outputs=outputs)
    model.compile(
        optimizer=keras.optimizers.Adam(learning_rate=LEARNING_RATE),
        loss='huber' if for_classification else custom_loss,
        metrics=['accuracy'] if for_classification else None
    )
    return model

def train_and_test(ticker, data_date, model_type="GRU", bidirectional=False, epochs=EPOCHS, batch_size=BATCH_SIZE):
    print(f"🔄 Training {model_type} {'Bidirectional ' if bidirectional else ''}model for {ticker} with data date {data_date.strftime('%Y-%m-%d')}...")
    try:
        X_train, X_test, y_reg_train, y_reg_test, y_clf_train, y_clf_test, scaler, dates, df, close_idx, _ = load_data(ticker)
    except Exception as e:
        print(f"⚠️ Error loading data: {e}")
        return None, None, None, None, None, None, None
    model_dir = f"models/{ticker}"
    os.makedirs(model_dir, exist_ok=True)
    tscv = TimeSeriesSplit(n_splits=N_FOLDS)
    reg_models, clf_models = [], []
    reg_histories, clf_histories = [], []
    dir_accuracies = []
    date_str = data_date.strftime("%Y-%m-%d")
    for fold, (train_idx, val_idx) in enumerate(tscv.split(X_train)):
        X_tr, X_val = X_train[train_idx], X_train[val_idx]
        y_reg_tr, y_reg_val = y_reg_train[train_idx], y_reg_train[val_idx]
        y_clf_tr, y_clf_val = y_clf_train[train_idx], y_clf_train[val_idx]
        reg_model = build_model(model_type, X_train.shape[1:], bidirectional=bidirectional, for_classification=False)
        early_stopping = EarlyStopping(monitor='val_loss', patience=PATIENCE, restore_best_weights=True)
        lr_scheduler = ReduceLROnPlateau(monitor='val_loss', factor=0.3, patience=2, min_lr=1e-6)
        reg_history = reg_model.fit(X_tr, y_reg_tr,
                                    validation_data=(X_val, y_reg_val),
                                    epochs=epochs, batch_size=batch_size,
                                    callbacks=[early_stopping, lr_scheduler],
                                    verbose=1)
        reg_model_path = os.path.join(model_dir, f"reg_model_{model_type}_fold{fold}_{date_str}.keras")
        reg_model.save(reg_model_path)
        print(f"Saved regression model fold {fold} to {reg_model_path}")
        reg_models.append(reg_model)
        reg_histories.append(reg_history)
        clf_model = build_model(model_type, X_train.shape[1:], bidirectional=bidirectional, for_classification=True)
        clf_history = clf_model.fit(X_tr, y_clf_tr,
                                    validation_data=(X_val, y_clf_val),
                                    epochs=epochs, batch_size=batch_size,
                                    callbacks=[early_stopping, lr_scheduler],
                                    verbose=1)
        clf_model_path = os.path.join(model_dir, f"clf_model_{model_type}_fold{fold}_{date_str}.keras")
        clf_model.save(clf_model_path)
        print(f"Saved classification model fold {fold} to {clf_model_path}")
        clf_models.append(clf_model)
        clf_histories.append(clf_history)
        y_reg_val_pred = reg_model.predict(X_val, verbose=0)
        dir_acc = calculate_directional_accuracy(y_reg_val, y_reg_val_pred)
        dir_accuracies.append(dir_acc)
    weights = np.array([0.4, 0.35, 0.25])  # if you have 3 models
    y_reg_pred = np.sum([w * model.predict(X_test, verbose=0) for w, model in zip(weights, reg_models)], axis=0)
    weights /= weights.sum()
    y_reg_pred = np.sum([w * model.predict(X_test, verbose=0) for w, model in zip(weights, reg_models)], axis=0)
    y_clf_pred = np.mean([model.predict(X_test, verbose=0) for model in clf_models], axis=0)
    direction_conf = (y_clf_pred > 0.5).astype(int)
    y_reg_pred_adj = y_reg_pred * (1 + 0.1 * (2 * direction_conf - 1))
    y_pred_actual = inverse_transform_single_column(y_reg_pred_adj, close_idx, scaler)
    y_test_actual = inverse_transform_single_column(y_reg_test.reshape(-1, 1), close_idx, scaler)
    plt.figure(figsize=(12, 6))
    plt.plot(dates[-len(y_test_actual):], y_test_actual, label="Actual", color='blue')
    plt.plot(dates[-len(y_pred_actual):], y_pred_actual, label="Predicted", color='orange')
    plt.title(f"{ticker} Stock Price Prediction ({model_type} {'Bidirectional' if bidirectional else ''})")
    plt.xlabel('Date')
    plt.ylabel("Price (₹)")
    plt.legend()
    plt.grid(True)
    plt.gca().xaxis.set_major_formatter(plt.matplotlib.dates.DateFormatter('%b %Y'))
    plt.gca().xaxis.set_major_locator(plt.matplotlib.dates.AutoDateLocator())
    plt.xticks(rotation=45)
    plt.tight_layout()
    plt.show()
    mape, rmse, directional_acc = calculate_metrics(y_test_actual, y_pred_actual)
    print(f"📏 MAPE: {mape:.2f}%")
    print(f"📏 RMSE: {rmse:.2f}")
    print(f"📏 Directional Accuracy: {directional_acc:.2f}%")
    from pandas.tseries.offsets import BDay
    future_reg_scaled = np.sum([w * model.predict(X_test[-1:], verbose=0) for w, model in zip(weights, reg_models)], axis=0)
    future_clf_pred = np.mean([model.predict(X_test[-1:], verbose=0) for model in clf_models], axis=0)
    future_direction = (future_clf_pred > 0.5).astype(int)
    future_reg_adj = future_reg_scaled * (1 + 0.1 * (2 * future_direction - 1))
    future_pred = inverse_transform_single_column(future_reg_adj, close_idx, scaler)[0]
    future_date = (dates[-1] + BDay(LOOKUP_STEP)).strftime("%d-%b-%Y")
    print(f"📌 Predicted price around {future_date}: ₹{future_pred:.2f}")
    return reg_models, clf_models, scaler, close_idx, X_test, y_reg_test, dates

def load_trained_models(ticker, model_type, n_folds=N_FOLDS):
    model_dir = f"models/{ticker}"
    latest_date = find_latest_model_date(ticker, model_type)
    if not latest_date:
        print("No saved models found")
        return None, None, None
    date_str = latest_date.strftime("%Y-%m-%d")
    reg_models = []
    clf_models = []
    for fold in range(n_folds):
        reg_path = os.path.join(model_dir, f"reg_model_{model_type}_fold{fold}_{date_str}.keras")
        clf_path = os.path.join(model_dir, f"clf_model_{model_type}_fold{fold}_{date_str}.keras")
        if not (os.path.exists(reg_path) and os.path.exists(clf_path)):
            print(f"Missing model files for fold {fold} for date {date_str}, retraining needed")
            return None, None, None
        reg_models.append(load_model(reg_path, custom_objects={"custom_loss": custom_loss}))
        clf_models.append(load_model(clf_path))
    return reg_models, clf_models, latest_date

def train_or_load_models(ticker, model_type="GRU", bidirectional=False, epochs=EPOCHS, batch_size=BATCH_SIZE):
    try:
        _, _, _, _, _, _, _, dates, _, _, _ = load_data(ticker)
        data_date = dates[-1]
    except Exception as e:
        print(f"Failed to load data: {e}")
        return None
    reg_models, clf_models, saved_date = load_trained_models(ticker, model_type)
    if saved_date and saved_date == data_date and reg_models and clf_models:
        print(f"✅ Loaded saved {model_type} models for {ticker} from {saved_date.strftime('%Y-%m-%d')}. Skipping training.")
        X_train, X_test, y_reg_train, y_reg_test, y_clf_train, y_clf_test, scaler, dates, df, close_idx, _ = load_data(ticker)
        return reg_models, clf_models, scaler, close_idx, X_test, y_reg_test, dates
    else:
        print(f"🚀 Retraining {model_type} models for {ticker} with data date {data_date.strftime('%Y-%m-%d')}.")
        return train_and_test(ticker, data_date, model_type, bidirectional, epochs, batch_size)

def predict_with_loaded_models(reg_models, clf_models, X_test, scaler, close_idx):
    weights = np.ones(len(reg_models)) / len(reg_models)
    y_reg_pred = np.sum([w * model.predict(X_test, verbose=0) for w, model in zip(weights, reg_models)], axis=0)
    y_clf_pred = np.mean([model.predict(X_test, verbose=0) for model in clf_models], axis=0)
    direction_conf = (y_clf_pred > 0.5).astype(int)
    y_reg_pred_adj = y_reg_pred * (1 + 0.1 * (2 * direction_conf - 1))
    y_pred_actual = inverse_transform_single_column(y_reg_pred_adj, close_idx, scaler)
    return y_pred_actual

def predict_and_evaluate(ticker, reg_models, clf_models, scaler, close_idx, X_test, y_reg_test, dates):
    y_pred_actual = predict_with_loaded_models(reg_models, clf_models, X_test, scaler, close_idx)
    y_test_actual = inverse_transform_single_column(y_reg_test.reshape(-1, 1), close_idx, scaler)
    mape, rmse, directional_acc = calculate_metrics(y_test_actual, y_pred_actual)
    print(f"📏 MAPE: {mape:.2f}%")
    print(f"📏 RMSE: {rmse:.2f}")
    print(f"📏 Directional Accuracy: {directional_acc:.2f}%")
    plt.figure(figsize=(12, 6))
    plt.plot(dates[-len(y_test_actual):], y_test_actual, label="Actual", color="blue")
    plt.plot(dates[-len(y_pred_actual):], y_pred_actual, label="Predicted", color="orange")
    plt.title(f"{ticker} Stock Price Prediction")
    plt.xlabel("Date")
    plt.ylabel("Price (₹)")
    plt.legend()
    plt.grid(True)
    plt.gca().xaxis.set_major_formatter(plt.matplotlib.dates.DateFormatter("%b %Y"))
    plt.gca().xaxis.set_major_locator(plt.matplotlib.dates.AutoDateLocator())
    plt.xticks(rotation=45)
    plt.tight_layout()
    plt.show()

    # Next day prediction
    weights = np.ones(len(reg_models)) / len(reg_models)
    future_reg_scaled = np.sum([w * model.predict(X_test[-1:], verbose=0) for w, model in zip(weights, reg_models)], axis=0)
    future_clf_pred = np.mean([model.predict(X_test[-1:], verbose=0) for model in clf_models], axis=0)
    future_direction = (future_clf_pred > 0.5).astype(int)
    future_reg_adj = future_reg_scaled * (1 + 0.1 * (2 * future_direction - 1))
    future_pred = inverse_transform_single_column(future_reg_adj, close_idx, scaler)[0]
    from pandas.tseries.offsets import BDay
    future_date = (dates[-1] + BDay(LOOKUP_STEP)).strftime("%d-%b-%Y")
    print(f"📌 Predicted price around {future_date}: ₹{future_pred:.2f}")

def fetch_symbols(index_name):
    urls = {
        "Nifty 50": "https://archives.nseindia.com/content/indices/ind_nifty50list.csv",
        "Nifty 100": "https://archives.nseindia.com/content/indices/ind_nifty100list.csv",
        "Nifty 200": "https://archives.nseindia.com/content/indices/ind_nifty200list.csv",
        "Nifty 500": "https://archives.nseindia.com/content/indices/ind_nifty500list.csv",
    }
    try:
        df = pd.read_csv(urls[index_name])
        return [str(sym) + ".NS" for sym in df['Symbol'].dropna()]
    except Exception as e:
        print(f"⚠️ Could not load {index_name}: {e}")
        return []

def run_ui():
    if not JUPYTER_AVAILABLE:
        print("⚠️ Interactive UI requires ipywidgets and Jupyter. Running in non-interactive mode.")
        train_and_test("ADANIENT.NS", model_type="GRU", bidirectional=False)
        return

    index_dropdown = widgets.Dropdown(
        options=["Nifty 50", "Nifty 100", "Nifty 200", "Nifty 500"],
        value="Nifty 50",
        description="Index:"
    )
    stock_dropdown = widgets.Dropdown(description="Stock:")
    model_dropdown = widgets.Dropdown(
        options=["GRU", "LSTM", "Conv1D", "Dense"],
        value="GRU",
        description="Model:"
    )
    bidirectional_toggle = widgets.Checkbox(
        value=False,
        description="Bidirectional",
        indent=False
    )
    button = widgets.Button(description="📈 Predict Stock")
    output = widgets.Output()

    def update_stock_options(change=None):
        index = index_dropdown.value
        symbols = fetch_symbols(index)
        if symbols:
            stock_dropdown.options = sorted(symbols)
            stock_dropdown.value = symbols[0]

    index_dropdown.observe(update_stock_options, names="value")

    def on_button_click(b):
        with output:
            output.clear_output()
            selected = stock_dropdown.value
            model_type = model_dropdown.value
            bidirectional = bidirectional_toggle.value
            result = train_or_load_models(selected, model_type, bidirectional)
            if not result:
                print(f"Failed to load or train models for {selected}")
                return
            if len(result) == 7:
                reg_models, clf_models, scaler, close_idx, X_test, y_reg_test, dates = result
                predict_and_evaluate(selected, reg_models, clf_models, scaler, close_idx, X_test, y_reg_test, dates)
            else:
                print("Unexpected result from train_or_load_models")

    button.on_click(on_button_click)

    display(widgets.VBox([
        widgets.HBox([index_dropdown, stock_dropdown]),
        widgets.HBox([model_dropdown, bidirectional_toggle]),
        button,
        output
    ]))

    update_stock_options()

if __name__ == "__main__":
    run_ui()


# In[ ]:





# In[ ]:




